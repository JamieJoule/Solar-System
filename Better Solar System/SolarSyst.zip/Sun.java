public class Sun extends SolarObject
{
	/**
	* creates a sun in centre
	*@param Double Diamater of sun,size
	*@param String Colour, the colour of the sun
	**/
	public Sun(double diam,String c)
	{
		this.setDiameter(diam);
		this.setColour(c);
	}
}